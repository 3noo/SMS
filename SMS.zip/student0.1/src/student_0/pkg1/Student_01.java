package student_0.pkg1;

/*
 * @Xhelion Brakaj User
 */
public class Student_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
